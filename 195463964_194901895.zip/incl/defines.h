#ifndef DEFINES_H
    #define DEFINES_H 

    #define AUX_CHAR 40
    #define MAX_CHAR 100
    #define TRUE 1
    #define FALSE 0
    #define ACTIVE 100
    #define NOT_ACTIVE -1
    #define FIN -100

    // Errores
    #define OK 0
    #define FAIL 1

#endif